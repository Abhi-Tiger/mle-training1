import argparse
import logging
import logging.config
import os

import joblib
import mlflow
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.tree import DecisionTreeRegressor

# Default logging configuration
LOGGING_DEFAULT_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {"format": "%(message)s"},
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "default",
            "level": "DEBUG",
        },
        "file": {
            "class": "logging.FileHandler",
            "formatter": "default",
            "level": "DEBUG",
            "filename": "logs/train.log",
        },
    },
    "root": {"level": "DEBUG", "handlers": ["console", "file"]},
}


def configure_logger(log_file=None, console=True, log_level="DEBUG"):
    if not log_file and not console:
        return logging.getLogger("null")

    logging.config.dictConfig(LOGGING_DEFAULT_CONFIG)
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, log_level))
        logger.addHandler(file_handler)

    if not console:
        for handler in logger.handlers:
            if isinstance(handler, logging.StreamHandler):
                logger.removeHandler(handler)

    return logger


def load_data(input_path):
    return pd.read_csv(input_path)


def prepare_data(data):
    data = data.dropna(subset=["total_bedrooms"])
    data = data.drop("ocean_proximity", axis=1)
    data_labels = data["median_house_value"].copy()
    data = data.drop("median_house_value", axis=1)

    imputer = SimpleImputer(strategy="median")
    imputer.fit(data)
    data_prepared = imputer.transform(data)
    return (
        pd.DataFrame(data_prepared, columns=data.columns, index=data.index),
        data_labels,
    )


def split_data(data, test_size, random_state, output_dir):
    train_set, val_set = train_test_split(
        data, test_size=test_size, random_state=random_state
    )
    train_set.to_csv(os.path.join(output_dir, "train.csv"), index=False)
    val_set.to_csv(os.path.join(output_dir, "val.csv"), index=False)


def train_models(X, y, output_path):
    # Linear Regression
    with mlflow.start_run(nested=True):
        lin_reg = LinearRegression()
        lin_reg.fit(X, y)
        joblib.dump(lin_reg, os.path.join(output_path, "linear_regression_model.pkl"))
        mlflow.log_param("model_type", "LinearRegression")
        mlflow.sklearn.log_model(lin_reg, "linear_regression_model")

    # Decision Tree
    with mlflow.start_run(nested=True):
        tree_reg = DecisionTreeRegressor(random_state=42)
        tree_reg.fit(X, y)
        joblib.dump(tree_reg, os.path.join(output_path, "decision_tree_model.pkl"))
        mlflow.log_param("model_type", "DecisionTreeRegressor")
        mlflow.sklearn.log_model(tree_reg, "decision_tree_model")

    # Random Forest with Grid Search
    with mlflow.start_run(nested=True):
        param_grid = [
            {"n_estimators": [3, 10, 30], "max_features": [2, 4, 6, 8]},
            {"bootstrap": [False], "n_estimators": [3, 10], "max_features": [2, 3, 4]},
        ]

        forest_reg = RandomForestRegressor(random_state=42)
        grid_search = GridSearchCV(
            forest_reg,
            param_grid,
            cv=5,
            scoring="neg_mean_squared_error",
            return_train_score=True,
        )
        grid_search.fit(X, y)
        joblib.dump(
            grid_search.best_estimator_,
            os.path.join(output_path, "random_forest_model.pkl"),
        )
        mlflow.log_param("model_type", "RandomForestRegressor")
        mlflow.sklearn.log_model(grid_search.best_estimator_, "random_forest_model")


def main():
    parser = argparse.ArgumentParser(
        description="Train models using the provided dataset."
    )
    parser.add_argument(
        "--input-path",
        type=str,
        default="data/raw/housing.csv",
        help="Path to the input dataset.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="data/processed",
        help="Path to save the split datasets.",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        default="artifacts",
        help="Path to save the trained models.",
    )
    parser.add_argument(
        "--log-level", type=str, default="DEBUG", help="Set the logging level"
    )
    parser.add_argument("--log-path", type=str, help="Path to the log file")
    parser.add_argument(
        "--no-console-log", action="store_true", help="Disable logging to console"
    )
    parser.add_argument(
        "--test-size",
        type=float,
        default=0.2,
        help="Size of the validation set (default: 0.2).",
    )
    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Random state for train-test split (default: 42).",
    )

    args = parser.parse_args()

    # Ensure the logs directory exists
    os.makedirs("logs", exist_ok=True)

    global logger
    logger = configure_logger(
        log_file=os.path.join("logs", "train.log"),
        console=not args.no_console_log,
        log_level=args.log_level.upper(),
    )

    logger.info("Starting the training process...")
    data = load_data(args.input_path)
    logger.info("Data loaded successfully.")

    split_data(data, args.test_size, args.random_state, args.output_dir)
    logger.info(
        f"Data split completed. Train and validation sets saved to {args.output_dir}"
    )

    train_data = load_data(os.path.join(args.output_dir, "train.csv"))
    X, y = prepare_data(train_data)
    logger.info("Data preparation completed.")

    os.makedirs(args.output_path, exist_ok=True)
    train_models(X, y, args.output_path)
    logger.info("Model training completed. Models saved to the specified output path.")


if __name__ == "__main__":
    main()
