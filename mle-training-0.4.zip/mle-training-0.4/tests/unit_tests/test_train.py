import os
import unittest

import pandas as pd

from src.HousePricePrediction.train import load_data


class TestTrain(unittest.TestCase):
    def setUp(self):
        self.data_folder = "data/processed"
        self.model_folder = "artifacts"

    def test_load_data(self):
        data = load_data(os.path.join(self.data_folder, "train.csv"))
        self.assertIsInstance(data, pd.DataFrame)
        self.assertIn("median_house_value", data.columns)

    def test_model_saved(self):
        model_path = os.path.join(self.model_folder, "random_forest_model.pkl")
        self.assertTrue(os.path.exists(model_path))


if __name__ == "__main__":
    unittest.main()
