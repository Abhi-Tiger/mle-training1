import argparse
import logging
import os
import tarfile
from urllib.request import urlretrieve

import pandas as pd


# Function to fetch data from URL and extract
def fetch_data(url, output_dir="data/raw"):
    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, "housing.tgz")
    urlretrieve(url, file_path)
    tar = tarfile.open(file_path)
    tar.extractall(path=output_dir)
    tar.close()
    logging.info(f"Data fetched and extracted to {output_dir}")


# Function to load the dataset from extracted CSV
def load_data(data_dir):
    csv_path = os.path.join(data_dir, "housing.csv")
    logging.info(f"Data loaded from {csv_path}")
    return pd.read_csv(csv_path)


def configure_logger(log_file=None, console=True, log_level="DEBUG"):
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))

    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, log_level))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(getattr(logging, log_level))
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    return logger


def main():
    parser = argparse.ArgumentParser(
        description="Download housing dataset and save it to the specified folder."
    )
    parser.add_argument(
        "--output-folder",
        type=str,
        default="data/raw",
        help="Path to the output folder for saving datasets.",
    )
    parser.add_argument(
        "--log-level", type=str, default="DEBUG", help="Set the logging level"
    )
    parser.add_argument(
        "--log-path",
        type=str,
        default="logs/ingest_data.log",
        help="Path to the log file",
    )
    parser.add_argument(
        "--no-console-log", action="store_true", help="Disable logging to console"
    )

    args = parser.parse_args()

    global logger
    logger = configure_logger(
        log_file=args.log_path,
        console=not args.no_console_log,
        log_level=args.log_level.upper(),
    )

    output_folder = args.output_folder

    # URL and output directory
    DOWNLOAD_ROOT = "https://raw.githubusercontent.com/ageron/handson-ml/master/"
    HOUSING_URL = DOWNLOAD_ROOT + "datasets/housing/housing.tgz"

    # Fetching data
    fetch_data(HOUSING_URL, output_folder)

    # Loading data
    data = load_data(output_folder)
    data.to_csv(os.path.join(output_folder, "housing.csv"), index=False)
    logger.info(f"Data successfully ingested. Output folder: {output_folder}")


if __name__ == "__main__":
    main()
