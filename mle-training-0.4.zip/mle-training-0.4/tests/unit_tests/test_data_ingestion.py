import os
import unittest

import pandas as pd

from src.HousePricePrediction.ingest_data import fetch_data, load_data

DOWNLOAD_ROOT = "https://raw.githubusercontent.com/ageron/handson-ml/master/"
HOUSING_URL = DOWNLOAD_ROOT + "datasets/housing/housing.tgz"


class TestIngestData(unittest.TestCase):
    def setUp(self):
        self.housing_path = "data/raw"
        fetch_data(HOUSING_URL)
        self.data = load_data(self.housing_path)

    def test_fetch_data(self):
        tgz_path = os.path.join(self.housing_path, "housing.tgz")
        self.assertTrue(os.path.exists(tgz_path))

    def test_load_data(self):
        self.assertIsInstance(self.data, pd.DataFrame)
        self.assertFalse(self.data.empty)
        self.assertIn("median_house_value", self.data.columns)


if __name__ == "__main__":
    unittest.main()
