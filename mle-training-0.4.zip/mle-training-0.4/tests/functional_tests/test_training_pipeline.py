import os
import subprocess

import pytest


@pytest.fixture(scope="session")
def setup_directories():
    data_folder = "data/processed"
    model_folder = "artifacts"
    logs_folder = "logs"
    return data_folder, model_folder, logs_folder


def test_ingest_data(setup_directories):
    data_folder, _, logs_folder = setup_directories
    ingest_script = "src/HousePricePrediction/ingest_data.py"

    result = subprocess.run(
        [
            "python",
            ingest_script,
            "--output-folder",
            data_folder,
            "--log-level",
            "INFO",
            "--log-path",
            os.path.join(logs_folder, "ingest_data.log"),
        ],
        capture_output=True,
    )

    assert (
        result.returncode == 0
    ), f"ingest_data.py script failed with return code {result.returncode}"
    assert os.path.exists(
        os.path.join(data_folder, "train.csv")
    ), "train.csv not found in data/processed"
    assert os.path.exists(
        os.path.join(data_folder, "val.csv")
    ), "test.csv not found in data/processed"


def test_train_model(setup_directories):
    data_folder, model_folder, logs_folder = setup_directories
    train_script = "src/HousePricePrediction/train.py"

    result = subprocess.run(
        [
            "python",
            train_script,
            "--output-dir",
            data_folder,
            "--output-path",
            model_folder,
            "--log-level",
            "INFO",
            "--log-path",
            os.path.join(logs_folder, "train.log"),
        ],
        capture_output=True,
    )

    assert (
        result.returncode == 0
    ), f"train.py script failed with return code {result.returncode}"
    assert os.path.exists(
        os.path.join(model_folder, "random_forest_model.pkl")
    ), "random_forest_model.pkl not found in artifacts folder"


def test_score_model(setup_directories):
    data_folder, model_folder, logs_folder = setup_directories
    score_script = "src/HousePricePrediction/score.py"

    result = subprocess.run(
        [
            "python",
            score_script,
            "--model-folder",
            model_folder,
            "--dataset-folder",
            data_folder,
            "--log-level",
            "INFO",
            "--log-path",
            os.path.join(logs_folder, "score.log"),
        ],
        capture_output=True,
    )

    assert (
        result.returncode == 0
    ), f"score.py script failed with return code {result.returncode}"
