from setuptools import find_packages, setup

setup(
    name="HousePricePrediction",
    version="0.3",
    packages=find_packages(),
    install_requires=[
        "argparse",
        "logging",
        "joblib",
        "pandas",
        "scikit-learn",
        "numpy",
        "pytest",
    ],
    entry_points={
        "console_scripts": [
            "ingest_data = src.HousePricePrediction.ingest_data:main",
            "train_model = src.HousePricePrediction.train:main",
            "score_model = src.HousePricePrediction.score:main",
            "run_main = src.main:main",
        ],
    },
)
