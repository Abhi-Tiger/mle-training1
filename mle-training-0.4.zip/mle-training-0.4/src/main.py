import os
import subprocess

import mlflow


def run_script(script_path, args):
    result = subprocess.run(
        ["python", script_path] + args,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(f"Script {script_path} failed with return code {result.returncode}")
        print(result.stdout)
        print(result.stderr)
        raise RuntimeError(f"{script_path} failed")
    else:
        print(f"Script {script_path} executed successfully")
        print(result.stdout)
        print(result.stderr)


def main():
    # Paths to your scripts
    ingest_script = "src/HousePricePrediction/ingest_data.py"
    train_script = "src/HousePricePrediction/train.py"
    score_script = "src/HousePricePrediction/score.py"

    # Arguments for ingest_data.py
    ingest_args = [
        "--output-folder",
        "data/raw",
        "--log-level",
        "INFO",
        "--log-path",
        os.path.join("logs", "ingest_data.log"),
    ]

    # Arguments for train.py
    train_args = [
        "--input-path",
        os.path.join("data", "raw", "housing.csv"),
        "--output-dir",
        "data/processed",
        "--output-path",
        "artifacts",
        "--log-level",
        "INFO",
        "--log-path",
        os.path.join("logs", "train.log"),
        "--test-size",
        "0.2",
        "--random-state",
        "42",
    ]

    # Arguments for score.py
    score_args = [
        "--model-folder",
        "artifacts",
        "--dataset-folder",
        "data/processed",
        "--output-folder",
        "data/processed",
        "--log-level",
        "INFO",
        "--log-path",
        os.path.join("logs", "score.log"),
    ]

    # Create nested runs
    experiment_id = mlflow.create_experiment("HousePricePrediction")
    with mlflow.start_run(
        run_name="PARENT_RUN",
        experiment_id=experiment_id,
        tags={"version": "v1", "priority": "P1"},
        description="parent",
    ) as parent_run:

        mlflow.log_param("parent", "yes")

        # Running the ingestion script as a child run
        with mlflow.start_run(
            run_name="INGEST_RUN",
            experiment_id=experiment_id,
            description="child",
            nested=True,
        ) as child_run:  # noqa: F841
            print("Running data ingestion script...")
            run_script(ingest_script, ingest_args)
            mlflow.log_param("step", "data_ingestion")

        # Running the training script as a child run
        with mlflow.start_run(
            run_name="TRAIN_RUN",
            experiment_id=experiment_id,
            description="child",
            nested=True,
        ) as child_run:  # noqa: F841
            print("Running model training script...")
            run_script(train_script, train_args)
            mlflow.log_param("step", "model_training")

        # Running the scoring script as a child run
        with mlflow.start_run(
            run_name="SCORE_RUN",
            experiment_id=experiment_id,
            description="child",
            nested=True,
        ) as child_run:  # noqa: F841
            print("Running model scoring script...")
            run_script(score_script, score_args)
            mlflow.log_param("step", "model_scoring")

    print("Parent run completed:")
    print(f"run_id: {parent_run.info.run_id}")
    print("description: {}".format(parent_run.data.tags.get("mlflow.note.content")))
    print("version tag value: {}".format(parent_run.data.tags.get("version")))
    print("priority tag value: {}".format(parent_run.data.tags.get("priority")))
    print("--")

    # Search all child runs with the parent id
    query = f"tags.mlflow.parentRunId = '{parent_run.info.run_id}'"
    results = mlflow.search_runs(experiment_ids=[experiment_id], filter_string=query)
    print("Child runs:")
    print(results[["run_id", "params.step", "tags.mlflow.runName"]])


if __name__ == "__main__":
    main()
