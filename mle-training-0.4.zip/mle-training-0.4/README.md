## House Price Prediction

The housing data can be downloaded from https://raw.githubusercontent.com/ageron/handson-ml/master/. The `src` folder has codes to work on the data. We have modelled the median house value on given housing data.

The following techniques have been used:

 - Linear regression
 - Decision Tree
 - Random Forest

### Steps performed
 - We prepare and clean the data. We check and impute for missing values.
 - Multiple sampling techinuqies are evaluated. The data set is split into train and val.
 - All the above said modelling techniques are tried in `src/HousePricePrediction/train.py` and evaluated in `src/HousePricePrediction/score.py`. The final metric used to evaluate is mean squared error.
 - Models, Metrics and parameters are tracked using MLflow. Check `src/main.py`

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/varun-tiger/mle-training.git
   cd mle-training
   ```

2. **Set up the conda environment:**
   ```bash
   conda env create -f deploy/conda/env.yml
   conda activate your_environment_name
   ```

   Replace `your_environment_name` with the name of your conda environment.

3. **Running the Code:**

   ### Usage

   #### Ingesting and Preparing Data


   To download and preprocess the housing dataset:

   ```bash
   python src/HousePricePrediction/ingest_data.py --output-folder data/raw
   ```
   You can change `data/raw` to desired output folder, these are default (recommended) arguments.

   #### Training Models

   To train models using the prepared dataset:

   ```bash
   python src/HousePricePrediction/train.py --input-path data/raw/housing.csv --output-dir data/processed --output-path artifacts
   ```
   Replace  `--input-path data/raw/housing.csv --output-dir data/processed --output-path artifacts` according to your requirements, these are default (recommended) arguments.
   #### Scoring Models

   To score trained models using validation data:

   ```bash
   python src/HousePricePrediction/score.py --model-folder artifacts --dataset-folder data/processed --output-folder data/processed
   ```
   Replace  `--model-folder artifacts --dataset-folder data/processed --output-folder data/processed` according to your requirements, these are default (recommended) arguments.

   ### main.py

   If you want to directly run all the above scripts using default arguments (recommended), you can run `src/main.py` file. This will run all the scripts together under a single parent MLflow run_id.
   ```bash
   python src/main.py
   ```
   ### MLflow UI
   Run the below command to get MLflow Tracking results.
   ```bash
   mlflow ui
   ```


### Documentation

   For more detailed documentation, including API references and usage examples, see [Documentation](docs/build/html/index.html).
