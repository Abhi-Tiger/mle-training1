def test_pkg_installation():
    try:
        __import__("src.HousePricePrediction")

    except ImportError as e:
        assert (
            False
        ), f"Error: {e}. HousePricePrediction package is not installed correctly."
