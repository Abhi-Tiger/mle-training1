import argparse
import logging
import logging.config
import os

import joblib
import mlflow
import mlflow.sklearn
import pandas as pd
from sklearn.metrics import mean_squared_error

# Default logging configuration
LOGGING_DEFAULT_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {"format": "%(message)s"},
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "default",
            "level": "DEBUG",
        },
        "file": {
            "class": "logging.FileHandler",
            "formatter": "default",
            "level": "DEBUG",
            "filename": "logs/score.log",
        },
    },
    "root": {"level": "DEBUG", "handlers": ["console", "file"]},
}


def configure_logger(log_file=None, console=True, log_level="DEBUG"):
    if not log_file and not console:
        return logging.getLogger("null")

    logging.config.dictConfig(LOGGING_DEFAULT_CONFIG)
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, log_level))
        logger.addHandler(file_handler)

    if not console:
        for handler in logger.handlers:
            if isinstance(handler, logging.StreamHandler):
                logger.removeHandler(handler)

    return logger


def load_data(input_path):
    return pd.read_csv(input_path)


def load_model(model_path):
    return joblib.load(model_path)


def score_model(model, X, y):
    predictions = model.predict(X)
    mse = mean_squared_error(y, predictions)
    return mse


def main():
    parser = argparse.ArgumentParser(
        description="Score the trained models using the validation dataset."
    )
    parser.add_argument(
        "--model-folder",
        type=str,
        default="artifacts",
        help="Path to the folder containing the trained models.",
    )
    parser.add_argument(
        "--dataset-folder",
        type=str,
        default="data/processed",
        help="Path to the folder containing the validation dataset.",
    )
    parser.add_argument(
        "--output-folder",
        type=str,
        default="data/processed",
        help="Path to save the scoring results.",
    )
    parser.add_argument(
        "--log-level", type=str, default="DEBUG", help="Set the logging level"
    )
    parser.add_argument("--log-path", type=str, help="Path to the log file")
    parser.add_argument(
        "--no-console-log", action="store_true", help="Disable logging to console"
    )

    args = parser.parse_args()

    global logger
    logger = configure_logger(
        log_file=args.log_path or "logs/score.log",
        console=not args.no_console_log,
        log_level=args.log_level.upper(),
    )

    logger.info("Starting the scoring process...")

    val_data_path = os.path.join(args.dataset_folder, "val.csv")
    models = {
        "linear_regression": os.path.join(
            args.model_folder, "linear_regression_model.pkl"
        ),
        "decision_tree": os.path.join(args.model_folder, "decision_tree_model.pkl"),
        "random_forest": os.path.join(args.model_folder, "random_forest_model.pkl"),
    }

    logger.info(f"Loading validation data from {val_data_path}")
    data = load_data(val_data_path)

    logger.info("Preparing validation data")
    data = data.dropna(subset=["total_bedrooms"])
    data = data.drop("ocean_proximity", axis=1)
    data_labels = data["median_house_value"].copy()
    data = data.drop("median_house_value", axis=1)

    scores = {}
    for model_name, model_path in models.items():
        logger.info(f"Loading model: {model_name} from {model_path}")
        model = load_model(model_path)

        logger.info(f"Scoring model: {model_name}")
        with mlflow.start_run():
            mse = score_model(model, data, data_labels)
            scores[model_name] = mse
            logger.info(f"{model_name} MSE: {mse}")
            mlflow.log_param("model_name", model_name)
            mlflow.log_metric("mse", mse)

    os.makedirs(args.output_folder, exist_ok=True)
    scores_path = os.path.join(args.output_folder, "model_scores.csv")

    logger.info(f"Saving scores to {scores_path}")
    scores_df = pd.DataFrame(list(scores.items()), columns=["Model", "MSE"])
    scores_df.to_csv(scores_path, index=False)

    logger.info("Scoring process completed.")


if __name__ == "__main__":
    main()
